﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace WcfService1
{
    public class Service1 : IService1
    {
        DAL dataaccess = new DAL();

        public void Update(Product_details items)
        {
            double total = items.Product_price * items.Item_number;
            int update = dataaccess.FunExecuteNonQuery("exec usp_update_product_itemno "+items.Item_number+","+total+","+items.Product_id+"");
        }
        public DataSet Show()
        {

            return dataaccess.FunDataSet("exec usp_productlist");
            
        }
        public int totalprice()
        {
            int price = 0;
            PRODUCT ob = new PRODUCT();
            ShoppingDataContext data = new ShoppingDataContext();
            var total = from c in data.PRODUCTs
                            where c.ITEM_NUMBER > 0
                            select c.PRODUCT_PRICE;
            foreach (var a in total)
            {
                price = (int)a + price;
            }
            return price;
        }
        public void Confirm(user_detail username)
        {
            Guid key=Guid.NewGuid();
            int data = dataaccess.FunExecuteNonQuery("exec usp_insert_nameqtyprc");
            string date = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            int d = dataaccess.FunExecuteNonQuery("exec  usp_update_idstatus '" + key + "','" + date + "','" + username.Username + "'");
        }
        public DataSet Orderlist(user_detail username)
        {
            return dataaccess.FunDataSet("exec usp_orderplaced '"+username.Username+"'");
        }

        public void settozero()
        {
            int update = dataaccess.FunExecuteNonQuery("exec usp_settozero");
        }
        public object count()
        {
            return dataaccess.FunExecuteScalar("select count(ITEM_NUMBER) from PRODUCT where ITEM_NUMBER>0");
        }

        public bool authentication(user_detail usernamepassword)
        {
            object read = dataaccess.FunExecuteScalar("exec usp_authentication '"+usernamepassword.Username+"','"+usernamepassword.Password+"'");

            if (read != null)
                return true;
            return false;
        }
    }
}
