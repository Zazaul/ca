﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf; 

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["test1ConnectionString"].ToString());
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("select ID,Name,Qty,Price from Order_details where Status='Pending'", con);
            DataTable dt = new DataTable();

            da.Fill(dt);
            con.Close();
            GridView1.DataSource = dt;
            GridView1.DataBind();


        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["test1ConnectionString"].ToString());
        con.Open();
        SqlCommand cmd = new SqlCommand("select TOP (1)ID from Order_details where Status='Pending' group by ID", con);
        object id = cmd.ExecuteScalar();
        con.Close();
        con.Open();
        SqlCommand cmd1 = new SqlCommand("select top(1)count(ID) from Order_details where Status='Pending' group by ID", con);
        object count = cmd1.ExecuteScalar();
        con.Close();
        con.Open();
        SqlDataAdapter da = new SqlDataAdapter("select ID,Name,Qty,Price from Order_details where ID='"+id.ToString()+"'",con);
        DataTable dt = new DataTable();
        
        da.Fill(dt);
        con.Close();

      
        for (int i = 0; i < Convert.ToInt32(count); i++)
        {
            string ID = dt.Rows[i].ItemArray[0].ToString();
            string Name = dt.Rows[i].ItemArray[1].ToString();
            string Qty = dt.Rows[i].ItemArray[2].ToString();
            string Price = dt.Rows[i].ItemArray[3].ToString();

            Document doc = new Document(iTextSharp.text.PageSize.LETTER, 10, 10, 42, 35);
            string address = (@"C:\test\" + id.ToString() + "" + i + ".pdf");
            PdfWriter writer = PdfWriter.GetInstance(doc, new FileStream(address, FileMode.Create));
            doc.Open();
            Paragraph paragraph = new Paragraph();
            paragraph.Add(ID+" ");
            paragraph.Add(Name + " ");
            paragraph.Add(Qty + " ");
            paragraph.Add(Price + " ");
            doc.Add(paragraph);
            doc.Close();

            con.Open();
            SqlCommand cmd2 = new SqlCommand("update Order_details set Status='Confirm',Time='" + Convert.ToString(DateTime.Now) + "', PDF='"+address+"' where ID='" + id + "'", con);
            int a = cmd2.ExecuteNonQuery();
            con.Close();
        }
    }
    protected void GridView1_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {
        string file = Path.Combine(ConfigurationManager.AppSettings["FilePath"], "test.docx");
        string id = GridView1.Rows[e.NewSelectedIndex].Cells[0].Text;
        Response.Clear();
        Response.ContentType = "application/octect-stream";
        Response.AppendHeader("context-disposition", "filename="+"test.txt");
        Response.TransmitFile(file);
        Response.End();
        //Response.Redirect("C:\test\test.txt");
    }
}