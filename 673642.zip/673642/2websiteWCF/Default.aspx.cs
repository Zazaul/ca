﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ServiceReference1;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    
    ServiceReference1.Service1Client service = new ServiceReference1.Service1Client();
    Service1Client client = new Service1Client();
      
    protected void Page_Load(object sender, EventArgs e)
    {
        //Uri baseAddress = new Uri("http://localhost:64278/Service1.svc?singleWsdl");
        //ClaimInfo serviceHost = new ClaimInfo(typeof(Service1));

        //W binding = new WSHttpBinding();
        //binding.OpenTimeout = new TimeSpan(0, 10, 0);
        //binding.CloseTimeout = new TimeSpan(0, 10, 0);
        //binding.SendTimeout = new TimeSpan(0, 10, 0);
        //binding.ReceiveTimeout = new TimeSpan(0, 10, 0);

        //serviceHost.AddServiceEndpoint("IService1", binding, baseAddress);
        //serviceHost.Open();
        if(!IsPostBack)
        {
            //var time = new TimeSpan(0, 3, 0);
            //client.Endpoint.Binding.CloseTimeout = time;
            //client.Endpoint.Binding.OpenTimeout = time;
            //client.Endpoint.Binding.ReceiveTimeout = time;
            //client.Endpoint.Binding.SendTimeout = time;

            GridView1.DataSource=service.Show();
            GridView1.DataBind();
        }
        
    }
    protected void submit_btn_Click(object sender, EventArgs e)
    {
        ClaimInfo insert = new ClaimInfo();
        
        insert.Claimno = Convert.ToInt32(claimno.Text);
        insert.Claimscheme = claimscheme.Text;
        insert.Centreno = centreno.Text;
        insert.Status = processed_rdbtn.Checked ? "Processed" : "Submitted";
        Guid uniquekey = Guid.NewGuid();
        insert.Guid = uniquekey;
        string message=service.insertclaiminfo(insert);
        Literal1.Text = message;
    }
}