﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ServiceReference1;

public partial class _Default : System.Web.UI.Page
{
    Arithmatic ob = new Arithmatic();
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        int a = Convert.ToInt32(txtFno.Text);
        int b = Convert.ToInt32(txtSno.Text);
        int result = ob.Add(a, b);
        lblResult.Text = result.ToString();
    }
    protected void btnSub_Click(object sender, EventArgs e)
    {
        int a = Convert.ToInt32(txtFno.Text);
        int b = Convert.ToInt32(txtSno.Text);
        int result = ob.Sub(a, b);
        lblResult.Text = result.ToString();
    }

    protected void BtnMul_Click(object sender, EventArgs e)
    {
        int a = Convert.ToInt32(txtFno.Text);
        int b = Convert.ToInt32(txtSno.Text);
        int result = ob.Mul(a, b);
        lblResult.Text = result.ToString();
    }
    protected void btnDiv_Click(object sender, EventArgs e)
    {
        int a = Convert.ToInt32(txtFno.Text);
        int b = Convert.ToInt32(txtSno.Text);
        int result = ob.Div(a, b);
        lblResult.Text = result.ToString();
    }
}