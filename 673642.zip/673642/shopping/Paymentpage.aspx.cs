﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ServiceReference1;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Paymentpage : System.Web.UI.Page
{
    ServiceReference1.Service1Client service = new ServiceReference1.Service1Client();

    static string check="";
    protected void Page_Load(object sender, EventArgs e)
    {

        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.Cache.SetExpires(DateTime.Now.AddDays(-1));
        Response.Cache.SetNoStore();
        if (!IsPostBack)
        {
            
            
            if (Session["username"] != null)
            {
                DataSet ds = new DataSet();
                ds = service.Show();
                GridView1.DataSource = ds;
                GridView1.DataBind();

                cost.Text = "Rs. "+service.totalprice().ToString();
                int totalprice = service.totalprice();
                service.Close();
                check = Request.QueryString["pagename"];
            }
            else
                Response.Redirect("loginpage.aspx");
        }

    }

    protected void Confirm_Click(object sender, EventArgs e)
    {
        user_detail user = new user_detail();
        string username = Session["username"].ToString();
        user.Username = username;
        service.Confirm(user);
        service.settozero();
        service.Close();
        Response.Redirect("CheckoutPage.aspx");

    }
    protected void back_Click(object sender, EventArgs e)
    {
        service.settozero();
        
        if(check=="home")
        Response.Redirect("home.aspx");
        if (check == "checkout")
            Response.Redirect("CheckoutPage.aspx");
    }
    protected void signout1_Click(object sender, EventArgs e)
    {
        Session.Abandon();
       
        Response.Redirect("loginpage.aspx");
        
    }
}