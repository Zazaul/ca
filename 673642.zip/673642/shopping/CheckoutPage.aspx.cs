﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ServiceReference1;
using System.Data;


public partial class CheckoutPage : System.Web.UI.Page
{
    ServiceReference1.Service1Client service = new ServiceReference1.Service1Client();
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.Cache.SetExpires(DateTime.Now.AddDays(-1));
        Response.Cache.SetNoStore();
        if (IsPostBack)
        {
            ClientScript.RegisterHiddenField("isPostBack", "1");
        }
        if (!IsPostBack)
        
        {
           
            if (Session["username"] != null)
            {
                show();
            }
            else
            {
                Response.Redirect("loginpage.aspx");
            }
        }
       
        
    }
    public void show()
    {
        try
        {
            string username = Session["username"].ToString();


            user_detail user = new user_detail();
            user.Username = username;
            GridView1.DataSource = service.Orderlist(user);
            ViewState["ds"] = service.Orderlist(user);
            GridView1.DataBind();
            service.Close();
        }
        catch (NullReferenceException ex)
        {
            Response.Redirect("loginpage.aspx");
        }
        
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Download")
        {
           
                Response.Clear();
                Response.ContentType = "application/octect-stream";
                Response.AppendHeader("content-disposition", "attachment; filename=" + e.CommandArgument);
                Response.TransmitFile(e.CommandArgument.ToString());
                Response.End();
             
        }
      
    }
    protected void back_Click(object sender, EventArgs e)
    {
        service.settozero();
        
        Response.Redirect("home.aspx");
    }
    
    protected void signout_Click(object sender, EventArgs e)
    {
        
        Session.Abandon();
       
        Response.Redirect("loginpage.aspx");
        
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            LinkButton a = (LinkButton)e.Row.Cells[5].FindControl("LinkButton1");
            LinkButton cmd = (LinkButton)e.Row.Cells[6].FindControl("LinkButton2");
            LinkButton reorder = (LinkButton)e.Row.Cells[7].FindControl("LinkButton3");
            if (e.Row.Cells[4].Text == "Pending")
            {
                a.Visible = false;
                cmd.Visible = false;
                reorder.Visible = false;
            }
        }
       
    }
    //protected void GridView1_PageIndexChanging1(object sender, GridViewPageEventArgs e)
    //{
    //    GridView1.PageIndex = e.NewPageIndex;
    //    show();
    //}
    protected void GridView1_Sorting(object sender, GridViewSortEventArgs e)
    {
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        ds=(DataSet)ViewState["ds"];
        dt = ds.Tables[0];
        dt.DefaultView.Sort = e.SortExpression + " " + GetSortDirection(e.SortExpression);
        GridView1.DataSource = dt;
        GridView1.DataBind();
    }
    private string GetSortDirection(string column)
    {


        string sortDirection = "ASC";


        string sortExpression = Convert.ToString(ViewState["SortExpression"]);

        if (sortExpression != null)
        {
            // Check if the same column is being sorted.
            // Otherwise, the default value can be returned.
            if (sortExpression == column)
            {
                string lastDirection = Convert.ToString(ViewState["SortDirection"]);
                if ((lastDirection != null) && (lastDirection == "ASC"))
                {
                    sortDirection = "DESC";
                }
            }
        }

        // Save new values in ViewState.
        ViewState["SortDirection"] = sortDirection;
        ViewState["SortExpression"] = column;

        return sortDirection;
    }
    protected void GridView1_PreRender(object sender, EventArgs e)
    {
       
        GridView1.UseAccessibleHeader = false;
        if(GridView1.Rows.Count!=0)
        GridView1.HeaderRow.TableSection = TableRowSection.TableHeader;
   
    }


    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        
        string id = GridView1.Rows[e.RowIndex].Cells[0].Text;
        string name = GridView1.Rows[e.RowIndex].Cells[1].Text;
        service.Delete(id, name);
        show();
        Label1.Text = "Order id "+id + " is deleted";
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        
        Product_details items = new Product_details();
        string productname = GridView1.SelectedRow.Cells[1].Text;
        string Qty = GridView1.SelectedRow.Cells[2].Text;
        string price = GridView1.SelectedRow.Cells[3].Text;
        items.Product_name = productname;
        items.Item_number = Convert.ToInt32(Qty);
        items.Product_price = Convert.ToInt32(price);
        service.Reorder(items);
        Response.Redirect("Paymentpage.aspx?pagename=checkout");
        
    }
}