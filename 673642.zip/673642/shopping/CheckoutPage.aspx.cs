﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ServiceReference1;
using System.Data;
public partial class CheckoutPage : System.Web.UI.Page
{
    ServiceReference1.Service1Client service = new ServiceReference1.Service1Client();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetExpires(DateTime.Now.AddDays(-1));
            Response.Cache.SetNoStore();
            if (Session["username"] != null)
           
            {
                show();
            }
            else
                Response.Redirect("loginpage.aspx");
        }
       
        
    }
    public void show()
    {
        string username = Session["username"].ToString();
        user_detail user = new user_detail();
        user.Username = username;
        GridView1.DataSource = service.Orderlist(user);
        ViewState["ds"]=service.Orderlist(user);
        GridView1.DataBind();
        service.Close();
        
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Download")
        {
           
                Response.Clear();
                Response.ContentType = "application/octect-stream";
                Response.AppendHeader("content-disposition", "filename=" + e.CommandArgument);
                Response.TransmitFile(e.CommandArgument.ToString());
                Response.End();
             
        }
        
    }
    protected void back_Click(object sender, EventArgs e)
    {
        service.settozero();
        Response.Redirect("home.aspx");
    }
    
    protected void signout_Click(object sender, EventArgs e)
    {
        
        Session.Abandon();
       
        Response.Redirect("loginpage.aspx");
        
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            LinkButton a = (LinkButton)e.Row.Cells[5].FindControl("LinkButton1");
            if (e.Row.Cells[4].Text == "Pending")
            {
                a.Visible = false;
            }
        }
       
    }
    //protected void GridView1_PageIndexChanging1(object sender, GridViewPageEventArgs e)
    //{
    //    GridView1.PageIndex = e.NewPageIndex;
    //    show();
    //}
    protected void GridView1_Sorting(object sender, GridViewSortEventArgs e)
    {
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        ds=(DataSet)ViewState["ds"];
        dt = ds.Tables[0];
        dt.DefaultView.Sort = e.SortExpression + " " + GetSortDirection(e.SortExpression);
        GridView1.DataSource = dt;
        GridView1.DataBind();
    }
    private string GetSortDirection(string column)
    {


        string sortDirection = "ASC";


        string sortExpression = Convert.ToString(ViewState["SortExpression"]);

        if (sortExpression != null)
        {
            // Check if the same column is being sorted.
            // Otherwise, the default value can be returned.
            if (sortExpression == column)
            {
                string lastDirection = Convert.ToString(ViewState["SortDirection"]);
                if ((lastDirection != null) && (lastDirection == "ASC"))
                {
                    sortDirection = "DESC";
                }
            }
        }

        // Save new values in ViewState.
        ViewState["SortDirection"] = sortDirection;
        ViewState["SortExpression"] = column;

        return sortDirection;
    }
    protected void GridView1_PreRender(object sender, EventArgs e)
    {
       
        GridView1.UseAccessibleHeader = false;
        if(GridView1.Rows.Count!=0)
        GridView1.HeaderRow.TableSection = TableRowSection.TableHeader;
   
    }
}