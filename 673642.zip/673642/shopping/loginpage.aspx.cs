﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ServiceReference1;

public partial class loginpage : System.Web.UI.Page
{
    ServiceReference1.Service1Client service = new ServiceReference1.Service1Client();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetExpires(DateTime.Now.AddDays(-1));
            Response.Cache.SetNoStore();
        }
    }
    protected void Submit_Click(object sender, EventArgs e)
    {
        user_detail user = new user_detail();
        user.Username = Userid.Text;
        user.Password = Password.Text;

        if (service.authentication(user))
        {
            Session["username"] = Userid.Text;
            Response.Redirect("home.aspx");
        }
        else
        {
            Invalidcredential.Text = "<span style='color:red'> *Invalid credentials </span>";
        }
    }
}