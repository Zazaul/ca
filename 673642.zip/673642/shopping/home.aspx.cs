﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ServiceReference1;

public partial class home : System.Web.UI.Page
{
    ServiceReference1.Service1Client service = new ServiceReference1.Service1Client();
    bool button1WasClicked = false;
    protected void Page_Load(object sender, EventArgs e)
    {
        ScriptManager manager = ScriptManager.GetCurrent(this.Page);

        if (!manager.IsInAsyncPostBack)
        {
            if (button1WasClicked == true)
            {
                iphoneXtext.Text = "";
                iphoneXpop.Text = "";

                oneplus5ttext.Text = "";
                oneplus5tpop.Text = "";

                vivov9text.Text = "";
                vivov9pop.Text = "";

                iphone8plustext.Text = "";
                iphone8pluspop.Text = "";

                iphone8text.Text = "";
                iphone8pop.Text = "";

                ipadprotext.Text = "";
                ipadpropop.Text = "";

                asustext.Text = "";
                asuspop.Text = "";

                macbookairtext.Text = "";
                macbookairpop.Text = "";

                macbookprotext.Text = "";
                macbookpropop.Text = "";

                applewatchtext.Text = "";
                applewatchpop.Text = "";
                service.settozero();
            }
        }
        
        if (!IsPostBack)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetExpires(DateTime.Now.AddDays(-1));
            Response.Cache.SetNoStore();

            if (Session["username"] != null)
            {
                service.settozero();
            }
            else
                Response.Redirect("loginpage.aspx");
        }
       
    }

    #region OK BUTTON CLICK FUNCTIONALITY
    protected void iphoneXpopok_btn_Click(object sender, EventArgs e)
    {
        if (iphoneXpop.Text != "")
        {
            Product_details items = new Product_details();
            string id = iphoneXlabel.Text;
            items.Product_id = int.Parse(id);
            items.Item_number = int.Parse(iphoneXpop.Text);
            items.Product_price = 85000;
            service.Update(items);
            service.Close();
        }
    }

    protected void oneplus5tpopok_btn_Click(object sender, EventArgs e)
    {
        if (oneplus5tpop.Text != "")
        {
            Product_details items = new Product_details();
            string id = oneplus5tlabel.Text;
            items.Product_id = int.Parse(id);
            items.Item_number = int.Parse(oneplus5tpop.Text);
            items.Product_price = 35000;
            service.Update(items);
            service.Close();
        }
    }
    protected void vivov9popok_btn_Click(object sender, EventArgs e)
    {
        if (vivov9pop.Text != "")
        {
            Product_details items = new Product_details();
            string id = vivov9.Text;
            items.Product_id = int.Parse(id);
            items.Item_number = int.Parse(vivov9pop.Text);
            items.Product_price = 22990;
            service.Update(items);
            service.Close();
        }
    }
    protected void iphone8pluspopok_btn_Click(object sender, EventArgs e)
    {
        if (iphone8pluspop.Text != "")
        {
            Product_details items = new Product_details();
            string id = iphone8pluslabel.Text;
            items.Product_id = int.Parse(id);
            items.Item_number = int.Parse(iphone8pluspop.Text);
            items.Product_price = 77000;
            service.Update(items);
            service.Close();
        }
    }

    protected void iphone8popok_btn_Click(object sender, EventArgs e)
    {
        if (iphone8pop.Text != "")
        {
            Product_details items = new Product_details();
            string id = iphone8label.Text;
            items.Product_id = int.Parse(id);
            items.Item_number = int.Parse(iphone8pop.Text);
            items.Product_price = 70000;
            service.Update(items);
            service.Close();
        }
    }
    protected void ipadpropopok_btn_Click(object sender, EventArgs e)
    {
        if (ipadpropop.Text != "")
        {
            Product_details items = new Product_details();
            string id = ipadprolabel.Text;
            items.Product_id = int.Parse(id);
            items.Item_number = int.Parse(ipadpropop.Text);
            items.Product_price = 52000;
            service.Update(items);
            service.Close();
        }
    }

    protected void asuspopok_btn_Click(object sender, EventArgs e)
    {
        if (asuspop.Text != "")
        {
            Product_details items = new Product_details();
            string id = asuslabel.Text;
            items.Product_id = int.Parse(id);
            items.Item_number = int.Parse(asuspop.Text);
            items.Product_price = 20000;
            service.Update(items);
            service.Close();
        }
    }
    protected void macbookairpopok_btn_Click(object sender, EventArgs e)
    {
        if (macbookairpop.Text != "")
        {
            Product_details items = new Product_details();
            string id = macbookairlabel.Text;
            items.Product_id = int.Parse(id);
            items.Item_number = int.Parse(macbookairpop.Text);
            items.Product_price = 65000;
            service.Update(items);
            service.Close();
        }
    }

    protected void macbookpropopok_btn_Click(object sender, EventArgs e)
    {
        if (macbookpropop.Text != "")
        {
            Product_details items = new Product_details();
            string id = macbookprolabel.Text;
            items.Product_id = int.Parse(id);
            items.Item_number = int.Parse(macbookpropop.Text);
            items.Product_price = 177000;
            service.Update(items);
            service.Close();
        }
    }

    protected void applewatchpopok_btn_Click(object sender, EventArgs e)
    {
        if (applewatchpop.Text != "")
        {
            Product_details items = new Product_details();
            string id = applewatchlabel.Text;
            items.Product_id = int.Parse(id);
            items.Item_number = int.Parse(applewatchpop.Text);
            items.Product_price = 22000;
            service.Update(items);
            service.Close();
        }
    }
    #endregion

    #region MINUS BUTTON CLICK FUNCTIONALITY
    protected void iphoneXminus_btn_Click(object sender, EventArgs e)
    {
        if (iphoneXtext.Text != "")
        {
            Product_details items = new Product_details();
            string id = iphoneXlabel.Text;
            items.Product_id = int.Parse(id);
            items.Item_number = int.Parse(iphoneXtext.Text);
            items.Product_price = 85000;
            service.Update(items);
            service.Close();
        }
    }

    protected void oneplus5tminus_btn_Click(object sender, EventArgs e)
    {
        if (oneplus5ttext.Text != "")
        {
            Product_details items = new Product_details();
            string id = oneplus5tlabel.Text;
            items.Product_id = int.Parse(id);
            items.Item_number = int.Parse(oneplus5ttext.Text);
            items.Product_price = 35000;
            service.Update(items);
            service.Close();
        }
    }

    protected void vivov6minus_btn_Click(object sender, EventArgs e)
    {
        if (vivov9text.Text != "")
        {
            Product_details items = new Product_details();
            string id = vivov9.Text;
            items.Product_id = int.Parse(id);
            items.Item_number = int.Parse(vivov9text.Text);
            items.Product_price = 22990;
            service.Update(items);
            service.Close();
        }
    }

    protected void iphone8plusminus_btn_Click(object sender, EventArgs e)
    {
        if (iphone8plustext.Text != "")
        {
            Product_details items = new Product_details();
            string id = iphone8pluslabel.Text;
            items.Product_id = int.Parse(id);
            items.Item_number = int.Parse(iphone8plustext.Text);
            items.Product_price = 77000;
            service.Update(items);
            service.Close();
        }
    }

    protected void iphone8minus_btn_Click(object sender, EventArgs e)
    {
        if (iphone8text.Text != "")
        {
            Product_details items = new Product_details();
            string id = iphone8label.Text;
            items.Product_id = int.Parse(id);
            items.Item_number = int.Parse(iphone8text.Text);
            items.Product_price = 70000;
            service.Update(items);
            service.Close();
        }
    }

    protected void ipadprominus_btn_Click(object sender, EventArgs e)
    {
        if (ipadprotext.Text != "")
        {
            Product_details items = new Product_details();
            string id = ipadprolabel.Text;
            items.Product_id = int.Parse(id);
            items.Item_number = int.Parse(ipadprotext.Text);
            items.Product_price = 52000;
            service.Update(items);
            service.Close();
        }
    }

    protected void asusminus_btn_Click(object sender, EventArgs e)
    {
        if (asustext.Text != "")
        {
            Product_details items = new Product_details();
            string id = asuslabel.Text;
            items.Product_id = int.Parse(id);
            items.Item_number = int.Parse(asustext.Text);
            items.Product_price = 20000;
            service.Update(items);
            service.Close();
        }
    }

    protected void macbookairtminus_btn_Click(object sender, EventArgs e)
    {
        if (macbookairtext.Text != "")
        {
            Product_details items = new Product_details();
            string id = macbookairlabel.Text;
            items.Product_id = int.Parse(id);
            items.Item_number = int.Parse(macbookairtext.Text);
            items.Product_price = 65000;
            service.Update(items);
            service.Close();
        }
    }

    protected void macbookprominus_btn_Click(object sender, EventArgs e)
    {
        if (macbookprotext.Text != "")
        {
            Product_details items = new Product_details();
            string id = macbookprolabel.Text;
            items.Product_id = int.Parse(id);
            items.Item_number = int.Parse(macbookprotext.Text);
            items.Product_price = 177000;
            service.Update(items);
            service.Close();
        }
    }

    protected void applewatchminus_btn_Click(object sender, EventArgs e)
    {
        if (applewatchtext.Text != "")
        {
            Product_details items = new Product_details();
            string id = applewatchlabel.Text;
            items.Product_id = int.Parse(id);
            items.Item_number = int.Parse(applewatchtext.Text);
            items.Product_price = 22000;
            service.Update(items);
            service.Close();
           
        }
    }
#endregion

    #region REDIRECTING EVENTS
    protected void Button2_Click(object sender, EventArgs e)
    {
        clear();
        Response.Redirect("CheckoutPage.aspx");
    }
    protected void btn_checkout_Click(object sender, EventArgs e)
    {
        button1WasClicked = true;
        object count = service.count();
        if (Convert.ToInt32(count) > 0)
        {
            clear();
            Response.Redirect("Paymentpage.aspx");
        }
        else
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('Please buy a product');window.location ='home.aspx';", true);
        }
    }
    #region clear method
    public void clear()
    {
        iphoneXtext.Text = "";
        iphoneXpop.Text = "";

        oneplus5ttext.Text = "";
        oneplus5tpop.Text = "";

        vivov9text.Text = "";
        vivov9pop.Text = "";

        iphone8plustext.Text = "";
        iphone8pluspop.Text = "";

        iphone8text.Text = "";
        iphone8pop.Text = "";

        ipadprotext.Text = "";
        ipadpropop.Text = "";

        asustext.Text = "";
        asuspop.Text = "";

        macbookairtext.Text = "";
        macbookairpop.Text = "";

        macbookprotext.Text = "";
        macbookpropop.Text = "";

        applewatchtext.Text = "";
        applewatchpop.Text = "";
    }
    #endregion

    #endregion

    protected void signout2_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Redirect("loginpage.aspx");
       
    }
   
}