﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Text;
using System.Xml;
public partial class _Default : System.Web.UI.Page
{
    static string key;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            
            show();
        }
    }
    public void show()
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ToString());
        con.Open();
        SqlDataAdapter da = new SqlDataAdapter("select * from claiminfo", con);
        DataTable dt = new DataTable();
        da.Fill(dt);
        con.Close();
        GridView1.DataSource = dt;
        GridView1.DataBind();
        ViewState["dt"] = dt;
       
    }
    protected void claimno_TextChanged(object sender, EventArgs e)
    {

    }
    protected void  submit_btn_Click(object sender, EventArgs e)
    {
         SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ToString());
        try
        {
           
            if (processed_rdbtn.Checked || submitted_rdbtn.Checked)
            {
                //string exportFilePath = Path.Combine(ConfigurationManager.AppSettings["FilePath"], "Data.txt");
                //StreamWriter sw = new StreamWriter(exportFilePath, append: true);
                //sw.WriteLine(DateTime.Now);
                //sw.WriteLine("{0},{1},{2},{3}", claimno.Text, claimscheme.Text, centreno.Text, processed_rdbtn.Checked ? "Processed" : "Submitted");
                //sw.WriteLine();
                Guid uniquekey = Guid.NewGuid();
                
               
                string s = processed_rdbtn.Checked ? "Processed" : "Submitted";
                con.Open();
                SqlCommand cmd = new SqlCommand("exec usp_claimins3 '"+uniquekey+"'," + claimno.Text + ",'" + claimscheme.Text + "','" + centreno.Text + "','" + DateTime.Now.ToString("yyyy-MM-dd") + "','" + s + "'", con);
                int a = cmd.ExecuteNonQuery();
                if (a > 0)
                {
                   
                    string exportFilePath = Path.Combine(ConfigurationManager.AppSettings["FilePath"], "Data1.xml");
                    
                    Stream xmlFile = new FileStream(exportFilePath,FileMode.Append);
                    XmlTextWriter xmlwriter=new XmlTextWriter(xmlFile,null);
                    xmlwriter.Formatting = Formatting.Indented;
                    xmlwriter.Indentation = 5;
                   
                    

                   xmlwriter.WriteStartDocument();
                   xmlwriter.WriteStartElement(Convert.ToString(DateTime.Now));
                   

                    xmlwriter.WriteStartElement(Convert.ToString(uniquekey));
                    xmlwriter.WriteAttributeString("Claim no",null);
                    xmlwriter.WriteString(claimno.Text);
                    xmlwriter.WriteEndElement();

                    xmlwriter.WriteStartElement(Convert.ToString(uniquekey));
                    xmlwriter.WriteAttributeString("Claim scheme",null);
                    xmlwriter.WriteString(claimscheme.Text);
                    xmlwriter.WriteEndElement();

                    xmlwriter.WriteStartElement(Convert.ToString(uniquekey));
                    xmlwriter.WriteAttributeString("Centre no",null);
                    xmlwriter.WriteString(centreno.Text);
                    xmlwriter.WriteEndElement();

                    xmlwriter.WriteStartElement(Convert.ToString(uniquekey));
                    xmlwriter.WriteAttributeString("Status",null);
                    xmlwriter.WriteString(s);
                    xmlwriter.WriteEndElement();

                   

                    xmlwriter.WriteEndDocument();
                    xmlwriter.Flush();
                    xmlwriter.Close();

                    show();
                    Literal2.Text = "Data submitted successfuly";
                }
                else
                    Literal2.Text = "Data submission unsuccessful";
                //sw.Close();
            }
            else
            {
                Literal1.Text = "Please select any one";
            }

        }
        catch (IOException a)
        {
            Literal1.Text = a.Message;
        }
        catch (Exception a)
        {
            Literal1.Text = a.GetType()+a.Message;
        }
        finally
        {
            con.Close();
        }
    }

 
    protected void update_Click(object sender, EventArgs e)
    {
        if (processed_rdbtn.Checked || submitted_rdbtn.Checked)
            {
            Guid gu=new Guid(key);
                string s = processed_rdbtn.Checked ? "Processed" : "Submitted";
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ToString());
        con.Open();
        SqlCommand cmd = new SqlCommand("update claiminfo set claimno="+claimno.Text+",claim_scheme='"+claimscheme.Text+"',centreno='"+centreno.Text+"',status='"+s+"' where guid='"+gu+"' ; ", con);
          
         int a = cmd.ExecuteNonQuery();
         if (a > 0)
         {
             Literal2.Text = "Data updated successfully";
             show();
         }
         else
             Literal2.Text = "Data updation unsuccessful";
            }
            else
            {
                Literal1.Text = "Please select any one";
            }
       
    }
    protected void Delete_Click(object sender, EventArgs e)
    {
        try
        {
            Guid gu = new Guid(key);

            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ToString());
            con.Open();
            SqlCommand cmd = new SqlCommand("delete from claiminfo where guid='" + gu + "'", con);

            int a = cmd.ExecuteNonQuery();
            if (a > 0)
            {
                Literal2.Text = "Data deleted successfully";
                show();
            }
            else
                Literal2.Text = "Data deletion unsuccessful";
        }
        catch (ArgumentNullException a)
        {
            Literal2.Text = "Please select one from grid";
        }
        
       
    }

 
    protected void GridView1_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {
       
        claimno.Text = GridView1.Rows[e.NewSelectedIndex].Cells[1].Text;    
        claimscheme.Text = GridView1.Rows[e.NewSelectedIndex].Cells[2].Text;
        centreno.Text = GridView1.Rows[e.NewSelectedIndex].Cells[3].Text;
        key = GridView1.DataKeys[e.NewSelectedIndex].Value.ToString();
        Literal2.Text = "";
        
      
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        show();
    }


    protected void GridView1_Sorting(object sender, GridViewSortEventArgs e)
    {
        DataTable dt = new DataTable();
        dt = (DataTable)ViewState["dt"];
        dt.DefaultView.Sort = e.SortExpression +" " + GetSortDirection(e.SortExpression); 
        GridView1.DataSource = dt;
        GridView1.DataBind();
    }
    private string GetSortDirection(string column)
    {

        
        string sortDirection = "ASC";

       
        string sortExpression = Convert.ToString(ViewState["SortExpression"]);

        if (sortExpression != null)
        {
            // Check if the same column is being sorted.
            // Otherwise, the default value can be returned.
            if (sortExpression == column)
            {
                string lastDirection = Convert.ToString(ViewState["SortDirection"]);
                if ((lastDirection != null) && (lastDirection == "ASC"))
                {
                    sortDirection = "DESC";
                }
            }
        }

        // Save new values in ViewState.
        ViewState["SortDirection"] = sortDirection;
        ViewState["SortExpression"] = column;

        return sortDirection;
    }
    protected void Search_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ToString());
         con.Open();
        if(claimno.Text!="" && claimscheme.Text!="" && centreno.Text!="")
              {
               SqlDataAdapter da = new SqlDataAdapter("select * from claiminfo where claimno=" +claimno.Text + "and claim_scheme='" + claimscheme.Text + "' and centreno='" + centreno.Text + "' ; ", con);
               DataTable dt=new DataTable();
               da.Fill(dt);
               con.Close();
               GridView1.DataSource=(dt);
               GridView1.DataBind();
               }


        else if (claimno.Text != "" && claimscheme.Text != "")
              {
               SqlDataAdapter da = new SqlDataAdapter("select * from claiminfo where claimno="+claimno.Text+" and claim_scheme='"+claimscheme.Text+"' ; ", con);
               DataTable dt=new DataTable();
               da.Fill(dt);
               con.Close();
               GridView1.DataSource=(dt);
               GridView1.DataBind();
              }
        else if (claimno.Text != "" && centreno.Text != "")
              {
                SqlDataAdapter da = new SqlDataAdapter("select * from claiminfo where claimno="+claimno.Text+" and centreno='"+centreno.Text+"' ; ", con);
                DataTable dt=new DataTable();
               da.Fill(dt);
               con.Close();
               GridView1.DataSource=(dt);
               GridView1.DataBind();
              
              }
        else if (claimscheme.Text != "" && centreno.Text != "")
              {
               SqlDataAdapter da = new SqlDataAdapter("select * from claiminfo where claim_scheme='"+claimscheme.Text+"' and centreno='"+centreno.Text+"' ; ", con);
               DataTable dt=new DataTable();
               da.Fill(dt);
               con.Close();
               GridView1.DataSource=(dt);
               GridView1.DataBind();
              
               }
        else if (claimno.Text !="")
        {
            SqlDataAdapter da = new SqlDataAdapter("select * from claiminfo where claimno=" + claimno.Text + "", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();
            GridView1.DataSource = (dt);
            GridView1.DataBind();
        }
        else if (claimscheme.Text != "")
        {
           
            SqlDataAdapter da = new SqlDataAdapter("select * from claiminfo where claim_scheme='" + claimscheme.Text + "'", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();
            GridView1.DataSource = (dt);
            GridView1.DataBind();

        }
        else if (centreno.Text != "")
        {
            SqlDataAdapter da = new SqlDataAdapter("select * from claiminfo where centreno='" + centreno.Text + "'", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();
            GridView1.DataSource = (dt);
            GridView1.DataBind();
        }
        else
        {
            show();
        }
    }
}
