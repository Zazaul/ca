﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace WcfService1
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IService1
    {

        [OperationContract]
        void Update(Product_details items);
        [OperationContract]
        DataSet Show();
        [OperationContract]
        int totalprice();
        [OperationContract]
        void Confirm();
        [OperationContract]
        DataSet Orderlist();

        [OperationContract]
        void settozero();
    }
    [DataContract]
    public class Product_details
     {
         int _product_id;
         string _product_name;
         int _product_price;
         int _item_number;
     
         [DataMember]
         public int Product_id
         {
           get { return _product_id; }
           set { _product_id = value; }
         }
        [DataMember]
        public string Product_name
        {
          get { return _product_name; }
          set { _product_name = value; }
        }
         [DataMember]
        public int Product_price
        {
          get { return _product_price; }
          set { _product_price = value; }
        }
        [DataMember]
        public int Item_number
        {
          get { return _item_number; }
          set { _item_number = value; }
        }
     
     }
    [DataContract]
    public class Order_Details
    {
        int _id;
        string _name;
        int _qty;
        int _price;
        string _status;
        string _pdf;

        [DataMember]
        public string Pdf
        {
          get { return _pdf; }
          set { _pdf = value; }
        }
        [DataMember]
        public string Status
        {
          get { return _status; }
          set { _status = value; }
        }
        
        [DataMember]
        public int Price
        {
          get { return _price; }
          set { _price = value; }
        }
        [DataMember]
        public int Qty
        {
          get { return _qty; }
          set { _qty = value; }
        }
        [DataMember]
        public string Name
        {
          get { return _name; }
          set { _name = value; }
        }
        [DataMember]
        public int Id
        {
          get { return _id; }
          set { _id = value; }
        }

    }
  
  
}
