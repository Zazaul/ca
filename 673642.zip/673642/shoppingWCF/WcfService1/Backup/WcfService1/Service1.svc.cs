﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace WcfService1
{
    public class Service1 : IService1
    {
        DAL dataaccess = new DAL();

        public void Update(Product_details items)
        {
            double total = items.Product_price * items.Item_number;
            int update = dataaccess.FunExecuteNonQuery("update PRODUCT set ITEM_NUMBER="+items.Item_number+" , PRODUCT_PRICE="+total+" where ID="+items.Product_id+"");
        }
        public DataSet Show()
        {
            
            return dataaccess.FunDataSet("select PRODUCT_NAME,ITEM_NUMBER,PRODUCT_PRICE from PRODUCT where ITEM_NUMBER>0");
            
        }
        public int totalprice()
        {
            int price = 0;
            PRODUCT ob = new PRODUCT();
            ShoppingDataContext data = new ShoppingDataContext();
            var total = from c in data.PRODUCTs
                            where c.ITEM_NUMBER > 0
                            select c.PRODUCT_PRICE;
            foreach (var a in total)
            {
                price = (int)a + price;
            }
            return price;
        }
        public void Confirm()
        {
            Guid key=Guid.NewGuid();
            int data=dataaccess.FunExecuteNonQuery("INSERT INTO Order_details(Name,Qty,Price) select PRODUCT_NAME,ITEM_NUMBER,PRODUCT_PRICE from PRODUCT where ITEM_NUMBER>0");
            int d = dataaccess.FunExecuteNonQuery("update Order_details set Status='Pending', ID='"+key+"' where Qty>0 and Status is null");
        }
        public DataSet Orderlist()
        {
            return dataaccess.FunDataSet("select ID,Name,Qty,Price,Status,PDF from Order_details");
        }

        public void settozero()
        {
            int update = dataaccess.FunExecuteNonQuery("Update PRODUCT set ITEM_NUMBER=0 where ITEM_NUMBER>0");
        }
    }
}
