﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.ServiceModel;
using wcf_for_status_update;
using System.Timers;
using System.Data.SqlClient;
using System.Configuration;

using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;

namespace hosting
{
    public partial class hosting_staus_update : ServiceBase
    {

        Timer timer = new Timer();
        public hosting_staus_update()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            timer.Elapsed += new ElapsedEventHandler(OnElapsedTime);
            timer.Interval = 120000;
            timer.Enabled = true;
        }

        protected override void OnStop()
        {
            timer.Enabled = false;

        }
        private void OnElapsedTime(object source, ElapsedEventArgs e)
        {

            //SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["test1ConnectionString"].ToString());
            //con.Open();
            //SqlCommand cmd = new SqlCommand("update Order_details set Status='Confirm',Time='"+Convert.ToString(DateTime.Now)+"' where Status='Pending'", con);
            //int a = cmd.ExecuteNonQuery();
            //con.Close();

            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["test1ConnectionString"].ToString());
            con.Open();
            SqlCommand cmd = new SqlCommand("exec usp_findid",con);
            object id = cmd.ExecuteScalar();
            con.Close();
            con.Open();
            SqlCommand cmd1 = new SqlCommand("exec usp_findidcount", con);
            object count = cmd1.ExecuteScalar();
            con.Close();
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("exec usp_createpdf '" + id.ToString()+ "'", con);
            DataTable dt = new DataTable();

            da.Fill(dt);
            con.Close();

            string date = DateTime.Now.AddDays(5).ToString("dd-MMMM-yyyy");
            for (int i = 0; i < Convert.ToInt32(count); i++)
            {
                string ID = dt.Rows[i].ItemArray[0].ToString();
                string Name = dt.Rows[i].ItemArray[1].ToString();
                string Qty = dt.Rows[i].ItemArray[2].ToString();
                string Price = dt.Rows[i].ItemArray[3].ToString();
                string username = dt.Rows[i].ItemArray[4].ToString();
                DateTime ordertime = DateTime.Parse(dt.Rows[i].ItemArray[5].ToString());
                string odertimes = ordertime.ToString("dd/MM/yyyy");
                DateTime  deliverytime = DateTime.Parse(dt.Rows[i].ItemArray[6].ToString());
                string deliverytimes = deliverytime.ToString("dd/MM/yyyy");
                Rectangle page = new Rectangle(PageSize.A4);
                page.EnableBorderSide(1);
                page.EnableBorderSide(2);
                page.EnableBorderSide(4);
                page.EnableBorderSide(8);
                page.BorderWidth = 10;
                page.BorderColor = new BaseColor(175, 231, 247);

                page.BackgroundColor = new BaseColor(209, 239, 249);
                Document doc = new Document(page, 40, 40, 40, 40);

                string address = (@"C:\test\" + id.ToString() + "" + i + ".pdf");
                PdfWriter writer = PdfWriter.GetInstance(doc, new FileStream(address, FileMode.Create));
                PdfPTable table = new PdfPTable(4);
                string imageURL = @"C:\Users\berabi\Documents\673642\shoppingWCF\WcfService1\hosting\image\logo.png";
                doc.Open();
                Paragraph paragraph = new Paragraph();
                iTextSharp.text.Image jpg = iTextSharp.text.Image.GetInstance(imageURL);
                //Resize image depend upon your need
                jpg.ScaleToFit(140f, 120f);
                //Give space before image
                jpg.SpacingBefore = 1f;
                //Give some space after the image
                jpg.SpacingAfter = 1f;
                jpg.Alignment = Element.ALIGN_RIGHT;
                paragraph.Add("             Date of order placed :" + odertimes + "\n\n\n             " + username.First().ToString().ToUpper() + username.Substring(1).ToLower() + " this is your order detail");
                paragraph.Add("\n");
                paragraph.Add("\n");
                paragraph.Add("\n");
                doc.Add(jpg);
                doc.Add(paragraph);
                
                
                table.AddCell("Order number");
                table.AddCell("Name of product");
                table.AddCell("Quantity bought");
                table.AddCell("Price");

                table.AddCell(ID);
                table.AddCell(Name);
                table.AddCell(Qty);
                table.AddCell(Price);
                doc.Add(table);
                Paragraph p2 = new Paragraph();
                p2.Add("\n\n\n             Your order will be delivered by :" + deliverytimes);
                doc.Add(p2);
                doc.Close();

                con.Open();
                SqlCommand cmd2 = new SqlCommand("exec usp_updatestatus '"+address+"','"+id.ToString()+"','"+Name+"',"+Qty+","+Price+"", con);
                int a = cmd2.ExecuteNonQuery();
                con.Close();

            }
        }
    }
}
